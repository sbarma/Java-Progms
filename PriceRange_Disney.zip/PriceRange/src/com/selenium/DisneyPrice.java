package com.selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.pageobject.PRange_Disney;

public class DisneyPrice {
	
	private static WebDriver driver = null;
	public static void main(String []args){
		System.setProperty("webdriver.gecko.driver", "D://geckodriver.exe");
		driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://disneyworld.disney.go.com/resorts/");
		
		PRange_Disney.clk_Range(driver).click(); // Click on Price Range drop down
		
		//Checks and Unchecks $($0-$175) check box
		PRange_Disney.chkbox1_Checked(driver).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		PRange_Disney.chkbox1_Unchecked(driver).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Checks and Unchecks $$($175-$250) check box
		PRange_Disney.chkbox2_Checked(driver).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		PRange_Disney.chkbox2_Unchecked(driver).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Checks and Unchecks $$$(Over $250) checkbox
		PRange_Disney.chkbox3_Checked(driver).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		PRange_Disney.chkbox3_Unchecked(driver).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//checks $($0-$175) & $$($175-$250) check boxes
		PRange_Disney.chkbox1_Checked(driver).click();
		PRange_Disney.chkbox2_Checked(driver).click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		

		//Unchecks $($0-$175) & $$($175-$250) check boxes
		PRange_Disney.chkbox1_Unchecked(driver).click();
		PRange_Disney.chkbox2_Unchecked(driver).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//checks $$($175-$250) & $$$(Over $250) check boxes
		PRange_Disney.chkbox2_Checked(driver).click();
		PRange_Disney.chkbox3_Checked(driver).click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		//unchecks $$($175-$250) & $$$(Over $250) check boxes
		PRange_Disney.chkbox2_Unchecked(driver).click();
		PRange_Disney.chkbox3_Unchecked(driver).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Checks $($0-$175)& $$$(Over $250) check boxes
		PRange_Disney.chkbox1_Checked(driver).click();
		PRange_Disney.chkbox3_Checked(driver).click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		////Unchecks $($0-$175)& $$$(Over $250) check boxes
		PRange_Disney.chkbox1_Unchecked(driver).click();
		PRange_Disney.chkbox3_Unchecked(driver).click();
		
		
	}//end of main

}//end of Disney

