package com.pageobject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PRange_Disney {
	 private static WebElement element=null;
	
	 //clk_Range method is to click on Price Range drop down
	public static WebElement clk_Range(WebDriver driver){
		element = driver.findElement(By.xpath("//legend[@class='facetGroupHeader']"));
		return element;
		
	}// end of clk_Range
	
	/*-------------------------Code for 1st check box---------------------------------------------------*/
	
	//chkbox1_Checked method checks the $($0-$175) check box
	public static WebElement chkbox1_Checked(WebDriver driver){
		element=driver.findElement(By.xpath("//div[@class='expandedList']/ol/li[1]/label"));
		System.out.println("Checkbox 1 checked");
		return element;
		
	}//end of chbox1_Checked
	
	
	//chkbox1_Checked method unchecks the $($0-$175) check box
	public static WebElement chkbox1_Unchecked(WebDriver driver){
		element=driver.findElement(By.xpath("//div[@class='expandedList']/ol/li[1]/label"));
		System.out.println("Checkbox 1 unchecked");
		return element;
	}//end of chbox1_Unchecked
	
	/*-------------------------Code for 2nd check box---------------------------------------------------*/
	
	//chkbox2_Checked method checks the $$($175-$250) check box
	public static WebElement chkbox2_Checked(WebDriver driver){
		element=driver.findElement(By.xpath("//div[@class='expandedList']/ol/li[2]/label"));
		System.out.println("Checkbox 2 checked");
		return element;
	}//end of chkbox2_Checked
	
	//chkbox2_Unchecked method unchecks the $$($175-$250) check box
	public static WebElement chkbox2_Unchecked(WebDriver driver){
		element=driver.findElement(By.xpath("//div[@class='expandedList']/ol/li[2]/label"));
		System.out.println("Checkbox 2 unchecked");
		return element;
	}//end of chkbox2_Unchecked
	
	/*-------------------------Code for 3rd check box---------------------------------------------------*/
	
	//chkbox3_Checked method checks the $$$(Over $250)
	public static WebElement chkbox3_Checked(WebDriver driver){
		element=driver.findElement(By.xpath("//div[@class='expandedList']/ol/li[3]/label"));
		System.out.println("Checkbox 3 checked");
		return element;
	}//end of chkbox3_Checked
	
	//chkbox3_UnChecked method unchecks the $$$(Over $250)
	public static WebElement chkbox3_Unchecked(WebDriver driver){
		element=driver.findElement(By.xpath("//div[@class='expandedList']/ol/li[3]/label"));
		System.out.println("Checkbox 3 unchecked");
		return element;
	}//end of chbox3_Unchecked

}//end of PRange class

